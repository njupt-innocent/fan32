# Library

This folder store the `.a` (binary library files) generated under compilation. The `.a` files can be compiled with other `.c` or `.cpp` files if correct `.h` files are included in them.