# Technology Library

This folder contains the technology library for the circuits (`.v`).