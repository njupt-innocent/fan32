## Introduction
   利用线程池遍历pattern数组，并把每个pattern分配给线程实现多线优化


